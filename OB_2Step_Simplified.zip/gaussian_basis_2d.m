function S = gaussian_basis_2d(x1, z, c1, c2, width)
N = length(c1); S = zeros(N,1);
for i=1:N
    S(i) = exp(-((x1 - c1(i))^2 + (z - c2(i))^2)/width^2);
end
end
