function S = gaussian_basis(x, centers, width)
N = length(centers); S = zeros(N,1);
for i=1:N
    S(i) = exp(-((x - centers(i))^2)/width^2);
end
end
