function S = gaussian_basis3(x, z, cx1, cx2, cz, width)
N = length(cx1); S = zeros(N,1);
for i=1:N
    S(i) = exp(-((x(1)-cx1(i))^2 + (x(2)-cx2(i))^2 + (z - cz(i))^2)/width^2);
end
end
