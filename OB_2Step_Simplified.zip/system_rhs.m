function dYdt = system_rhs(t, Y, params)
x1 = Y(1); x2 = Y(2);
idx = 3;
Wf1 = Y(idx:idx+params.n_neurons_1-1); idx = idx + params.n_neurons_1;
Wc1 = Y(idx:idx+params.n_neurons_1-1); idx = idx + params.n_neurons_1;
Wa1 = Y(idx:idx+params.n_neurons_1-1); idx = idx + params.n_neurons_1;
Wf2 = Y(idx:idx+params.n_neurons_2-1); idx = idx + params.n_neurons_2;
Wc2 = Y(idx:idx+params.n_neurons_2-1); idx = idx + params.n_neurons_2;
Wa2 = Y(idx:idx+params.n_neurons_2-1);

yr = 5 * cos(0.6 * t); ydot = -3 * sin(0.6 * t);
z1 = x1 - yr;
S_f1 = gaussian_basis(x1, params.centers_f1_x1, params.width_s1);
S_J1 = gaussian_basis_2d(x1, z1, params.centers_J1_x1, params.centers_J1_z1, params.width_s1);
alpha1 = -params.beta1*z1 - Wf1'*S_f1 - 0.5*Wa1'*S_J1;
z2 = x2 - alpha1;
x_bar2 = [x1; x2];
S_f2 = gaussian_basis2(x_bar2, params.centers_f2_x1, params.centers_f2_x2, params.width_s2);
S_J2 = gaussian_basis3(x_bar2, z2, params.centers_J2_x1, params.centers_J2_x2, params.centers_J2_z2, params.width_s2);
u = -params.beta2*z2 - Wf2'*S_f2 - 0.5*Wa2'*S_J2;

dx1 = -cos(2*x1)^2 + x2;
dx2 = 5 + cos(x1)*sin(x2)^2 + u;
dWf1 = params.Gamma1 * (S_f1 * z1 - params.sigma1 * Wf1);
dWc1 = -params.gamma_c1 * (S_J1 * S_J1') * Wc1;
dWa1 = - (S_J1 * S_J1') * (params.gamma_a1*(Wa1 - Wc1) + params.gamma_c1*Wc1);
dWf2 = params.Gamma_f2 * (S_f2 * z2 - params.sigma2 * Wf2);
dWc2 = -params.gamma_c2 * (S_J2 * S_J2') * Wc2;
dWa2 = - (S_J2 * S_J2') * (params.gamma_a2*(Wa2 - Wc2) + params.gamma_c2*Wc2);
dYdt = [dx1; dx2; dWf1; dWc1; dWa1; dWf2; dWc2; dWa2];
end
