clear; clc; close all;
fprintf('Starting simulation...\n');

% Simulation time
tspan = [0 15];

% Initial conditions for system states
x0 = [2; 3];

% --- Parameters ---
params = struct();
params.n_neurons_1 = 24; params.beta1 = 10;
params.Gamma1 = 1.8 * eye(params.n_neurons_1);
params.sigma1 = 3.6; params.gamma_c1 = 14; params.gamma_a1 = 18; params.width_s1 = 2;
params.n_neurons_2 = 32; params.beta2 = 8;
params.Gamma_f2 = 1.4 * eye(params.n_neurons_2);
params.sigma2 = 2.8; params.gamma_c2 = 13; params.gamma_a2 = 15; params.width_s2 = 2;

Wf1_hat0 = 0.4 * ones(params.n_neurons_1, 1);
Wc1_hat0 = 0.4 * ones(params.n_neurons_1, 1);
Wa1_hat0 = 1.2 * ones(params.n_neurons_1, 1);
Wf2_hat0 = 0.8 * ones(params.n_neurons_2, 1);
Wc2_hat0 = 0.6 * ones(params.n_neurons_2, 1);
Wa2_hat0 = 1.3 * ones(params.n_neurons_2, 1);

% Basis centers
params.centers_f1_x1 = linspace(8, 8 - (2/3)*(params.n_neurons_1 - 1), params.n_neurons_1);
params.centers_J1_x1 = params.centers_f1_x1; params.centers_J1_z1 = params.centers_f1_x1;
params.centers_f2_x1 = linspace(8, 8 - 0.5*(params.n_neurons_2 - 1), params.n_neurons_2);
params.centers_f2_x2 = params.centers_f2_x1;
params.centers_J2_x1 = params.centers_f2_x1; params.centers_J2_x2 = params.centers_f2_x1;
params.centers_J2_z2 = params.centers_f2_x1;

Y0 = [x0; Wf1_hat0; Wc1_hat0; Wa1_hat0; Wf2_hat0; Wc2_hat0; Wa2_hat0];
options = odeset('RelTol',1e-5,'AbsTol',1e-5, 'Stats','off');
[T, Y_sol] = ode45(@(t,y) system_rhs(t, y, params), tspan, Y0, options);
fprintf('Simulation finished.\n');

% Extract system states
x1 = Y_sol(:,1); x2 = Y_sol(:,2);
yr = 5 * cos(0.6 * T); z1 = x1 - yr;

% Plot
figure;
subplot(2,1,1); plot(T, x1, 'b', T, yr, 'r--'); legend('x_1', 'y_r'); grid on;
title('Tracking Performance'); xlabel('Time (s)');
subplot(2,1,2); plot(T, z1); title('z_1(t)'); xlabel('Time (s)'); grid on;
